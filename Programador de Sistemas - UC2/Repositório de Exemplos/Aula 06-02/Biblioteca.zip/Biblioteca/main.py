#Aula 06-02
#Conteúdo: Revisão Geral de Implementação de Banco de Dados com Python
#Programa: Sistema de Gerenciamento de Biblioteca
#Objetivos:
#   - Criar modelo físico de dados
#   - Entidades: Livros e Clientes Relacionamentos: Aluguel
#   - Criar banco de dados e tabelas
#   - Integrar banco com Python e criar funções de manipulação das tabelas

